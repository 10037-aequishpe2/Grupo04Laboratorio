<?php
  define("SERVER","db");
  define("USER","root");
  define("PASS","test");
  define("BD","veris");
  define("PATH","../../imagenes/usuarios/");
 ?>